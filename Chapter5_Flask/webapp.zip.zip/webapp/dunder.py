print('we start off in:', __name__)
if __name__ =='__main__':
    print('and end up in', __name__)